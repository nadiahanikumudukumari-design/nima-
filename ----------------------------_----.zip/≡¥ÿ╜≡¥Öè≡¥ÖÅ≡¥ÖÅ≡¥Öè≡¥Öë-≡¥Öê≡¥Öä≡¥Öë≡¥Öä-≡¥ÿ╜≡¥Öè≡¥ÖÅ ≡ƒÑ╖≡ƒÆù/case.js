/**

 * RDG bot X - Tricolors theme
 # Tukang copas 
 
**/

require('./lib/system/config')
require('./lib/system/menu')
require('./lib/system/gear.js')
const { ytmp4,facebook } = require('sadaslk-dlcore');
const { exec, spawn, execSync } = require("child_process")
const fs = require('fs')
const qs = require("querystring") 
const fsx = require('fs-extra')
const util = require('util')
const fetch = require('node-fetch')
const axios = require('axios')
const cheerio = require('cheerio')
const { performance } = require("perf_hooks");
const { TelegraPH } = require("./lib/TelegraPH")
const { remini, jarak, ssweb, tiktok, PlayStore, BukaLapak, pinterest, stickersearch, lirik } = require("./lib/scraper")
const process = require('process');
const moment = require("moment-timezone")
const os = require('os');
const didyoumean = require('didyoumean');
const checkDiskSpace = require('check-disk-space').default;
const speed = require('performance-now')
const similarity = require('similarity');
const X = "`"
const chalk = require("chalk")
const { generateWAMessage, areJidsSameUser, proto, downloadContentFromMessage, prepareWAMessageMedia, generateWAMessageFromContent, generateWAMessageContent} = require("@whiskeysockets/baileys")
const { default: makeWASocket, useMultiFileAuthState } = require("@whiskeysockets/baileys")
const more = String.fromCharCode(8206);
const readmore = more.repeat(4800)
const { bytesToSize, checkBandwidth, formatSize, getBuffer, isUrl, jsonformat, nganuin, pickRandom, runtime, shorturl, formatp, color, getGroupAdmins } = require("./lib/myfunc");
const { FajarNews, BBCNews, metroNews, CNNNews, iNews, KumparanNews, TribunNews, DailyNews, DetikNews, OkezoneNews, CNBCNews, KompasNews, SindoNews, TempoNews, IndozoneNews, AntaraNews, RepublikaNews, VivaNews, KontanNews, MerdekaNews, KomikuSearch, AniPlanetSearch, KomikFoxSearch, KomikStationSearch, MangakuSearch, KiryuuSearch, KissMangaSearch, KlikMangaSearch, PalingMurah, LayarKaca21, AminoApps, Mangatoon, WAModsSearch, Emojis, CoronaInfo, JalanTikusMeme,Cerpen, Quotes, Couples, Darkjokes } = require("dhn-api");
const { addExif } = require('./lib/exif')
const { youtube } = require("btch-downloader");
const search = require("yt-search");
const fg = require('api-dylux')
module.exports = ptz = async (ptz, m, chatUpdate, store) => {
try {
const body = (m && m?.mtype) ? (
m?.mtype === 'conversation' ? m?.message?.conversation :
m?.mtype === 'imageMessage' ? m?.message?.imageMessage?.caption :
m?.mtype === 'videoMessage' ? m?.message?.videoMessage?.caption :
m?.mtype === 'extendedTextMessage' ? m?.message?.extendedTextMessage?.text :
m?.mtype === 'buttonsResponseMessage' ? m?.message.buttonsResponseMessage.selectedButtonId :
m?.mtype === 'listResponseMessage' ? m?.message?.listResponseMessage?.singleSelectReply?.selectedRowId :
m?.mtype === 'interactiveResponseMessage' ? appenTextMessage(JSON.parse(m?.msg.nativeFlowResponseMessage.paramsJson).id, chatUpdate) :
m?.mtype === 'templateButtonReplyMessage' ? appenTextMessage(m?.msg.selectedId, chatUpdate) :
m?.mtype === 'messageContextInfo' ? (m?.message.buttonsResponseMessage?.selectedButtonId || m?.message.listResponseMessage?.singleSelectReply.selectedRowId || m?.text) :
    ''
) : '';
 async function appenTextMessage(text, chatUpdate) {
        let messages = await generateWAMessage(m?.chat, { text: text, mentions: m?.mentionedJid }, {
            userJid: ptz.user.id,
            quoted:m?.quoted && m?.quoted.fakeObj
        })
        messages.key.fromMe = areJidsSameUser(m?.sender, ptz.user.id)
        messages.key.id = m?.key.id
        messages.pushName = m?.pushName
        if (m?.isGroup) messages.participant = m?.sender
        let msg = {
            ...chatUpdate,
            messages: [proto.WebMessageInfo.fromObject(messages)],
            type: 'append'}
ptz.ev.emit('messages.upsert', msg)}       
const budy = (m && typeof m?.text === 'string') ? m?.text : '';
const prefix = /^[°zZ#@*+,.?''():√%!¢£¥€π¤ΠΦ_&<`™©®Δ^βα~¦|/\\©^]/.test(body) ? body.match(/^[°zZ#@*+,.?''():√%¢£¥€π¤ΠΦ_&<!`™©®Δ^βα~¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const args = body.trim().split(/ +/).slice(1);
const full_args = body.replace(command, '').slice(1).trim();
const pushname = m?.pushName || "No Name";
const botNumber = await ptz.decodeJid(ptz.user.id);
const newowner = JSON.parse(fs.readFileSync('./lib/json/owner.json'))
const isCreator = (m && m?.sender && [botNumber, ...newowner,...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m?.sender)) || false;
const itsMe = (m && m?.sender && m?.sender == botNumber) || false;
const banned = JSON.parse(fs.readFileSync('./lib/json/banned.json'))
const isBan = banned.includes(m.sender)
const text = q = args.join(" ");
const fatkuns = m && (m?.quoted || m);
const quoted = (fatkuns?.mtype == 'buttonsMessage') ? fatkuns[Object.keys(fatkuns)[1]] :
(fatkuns?.mtype == 'templateMessage') ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] :
(fatkuns?.mtype == 'product') ? fatkuns[Object.keys(fatkuns)[0]] :
m?.quoted || m;
const mime = ((quoted?.msg || quoted) || {}).mimetype || '';
const qmsg = (quoted?.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);
//group
const groupMetadata = m?.isGroup ? await ptz.groupMetadata(m?.chat).catch(e => {}) : {};
const groupName = m?.isGroup ? groupMetadata.subject || '' : '';
const participants = m?.isGroup ? await groupMetadata.participants || [] : [];
const groupAdmins = m?.isGroup ? await getGroupAdmins(participants) || [] : [];
const isBotAdmins = m?.isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = m?.isGroup ? groupAdmins.includes(m?.sender) : false;
const groupOwner = m?.isGroup ? groupMetadata.owner || '' : '';
const isGroupOwner = m?.isGroup ? (groupOwner ? groupOwner : groupAdmins).includes(m?.sender) : false;
//================== [ TIME ] ==================//
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')

const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if(time2 < "23:59:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ️'
        }
        if(time2 < "19:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴇᴛᴀɴɢ'
        }
        if(time2 < "18:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴏʀᴇ'
        }
        if(time2 < "15:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱɪᴀɴɢ️'
        }
        if(time2 < "10:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ'
        }
        if(time2 < "05:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴜʙᴜʜ'
        }
        if(time2 < "03:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴛᴇɴɢᴀʜ ᴍᴀʟᴀᴍ'
        }
//================== [ DATABASE ] ==================//
try {
let isNumber = x => typeof x === 'number' && !isNaN(x)
let user = global.db.data.users[m?.sender]
if (typeof user !== 'object') global.db.data.users[m?.sender] = {}
if (user) {
if (!('hitcmd' in user)) user.hitcmd = 0
if (!('bits' in user)) user.bits = 0
if (!isNumber(user.afkTime)) user.afkTime = -1
if (!isNumber(user.limit)) user.limit = 270
if (!('afkReason' in user)) user.afkReason = ''
} else global.db.data.users[m?.sender] = {
hitcmd: 0,
bits: 0,
afkTime: -1,
limit: 271,
afkReason: '',
}
 let chats = global.db.data.chats[m?.chat]
 if (typeof chats !== 'object') global.db.data.chats[m?.chat] = {}
 if (chats) {
 if (!('isBanned' in chat)) chat.isBanned = false
 if (!('mute' in chat)) chat.mute = false
 } else global.db.data.chats[m?.chat] = {
 isBanned: false,
 mute: false,
}
let setting = global.db.data.settings[botNumber]
if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
if (setting) {
if (!('autoread' in setting)) setting.autoread = false
if (!("public" in settings)) settings.public = true
if (!('setkota' in setting)) setting.setkota = "Makassar"
if (!("onlypc" in settings)) settings.onlypc = false
if (!("onlygc" in settings)) settings.onlygc = false
} else global.db.data.settings[botNumber] = {
 autoread: false,
 public: true,
 setkota: "Makkasar",
 onlypc: false,
 onlygc: false
}
} catch (err) {
}
const userdb = global.db.data.users[m.sender]
const settingdb = global.db.data.settings[botNumber]
const chatdb = global.db.data.chats[m.chat]
const used = process.memoryUsage();
const cpus = os.cpus().map((cpu) => {
cpu.total = Object.keys(cpu.times).reduce(
(last, type) => last + cpu.times[type],
0,
);
return cpu;
});
const cpu = cpus.reduce(
(last, cpu, _, { length }) => {
last.total += cpu.total;
last.speed += cpu.speed / length;
last.times.user += cpu.times.user;
last.times.nice += cpu.times.nice;
last.times.sys += cpu.times.sys;
last.times.idle += cpu.times.idle;
last.times.irq += cpu.times.irq;
return last;
},
{
speed: 0,
total: 0,
times: {
user: 0,
nice: 0,
sys: 0,
idle: 0,
irq: 0,
},
},
);
var date = new Date();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
var ram = `${formatSize(process.memoryUsage().heapUsed)} / ${formatSize(os.totalmem)}`;
var cpuuuu = os.cpus();
var sisaram = `${Math.round(os.freemem)}`;
var totalram = `${Math.round(os.totalmem)}`;
var persenram = (sisaram / totalram) * 100;
var persenramm = 100 - persenram;
var ramused = totalram - sisaram;
var space = await checkDiskSpace(process.cwd());
var freespace = `${Math.round(space.free)}`;
var totalspace = `${Math.round(space.size)}`;
var diskused = totalspace - freespace;
var neww = performance.now();
var oldd = performance.now();
let timestamp = speed();
let latensi = speed() - timestamp;
var { download, upload } = await checkBandwidth();
let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
async function pomf(media) {
  return new Promise(async (resolve, reject) => {
    const formData = new FormData();
    formData.append('files[]', media, { 
      filename: new Date() * 1 + '.jpg' 
    });
    await axios.post('https://pomf2.lain.la/upload.php', formData, {
      headers: {
        ...formData.getHeaders(),
      },
    })
    .then((response) => {
      resolve(response.data);
    })
    .catch((error) => {
      resolve(error?.response);
    });
  });
}
const timeday = `${hariini} - ${wib}`
const prem = JSON.parse(fs.readFileSync("./lib/json/premium.json"))
const isPremium = prem.includes(m.sender)
const fsaluran = { key : {
remoteJid: '0@s.whatsapp.net',
participant : '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: '120363210705976689@newsletter',
    newsletterName: '',
    caption: body
}}}
const reply = async(teks, id = m.chat) => {
ptz.sendMessage(id, {
            document: fs.readFileSync("./package.json"),
           fileName: 'Switch-Blade',
           fileLength: 99999999999999,
            mimetype: 'image/png',
           jpegThumbnail:fs.readFileSync("./lib/Image/doc.jpg"),
            caption: "\n" + teks,
}, { quoted:fsaluran,ephemeralExpiration: 86400});
}
const resver = `╒─━─• *\`⟨  ＵＳＥＲ － ＩＮＦＯ  ⟩\`* 
│  
│ㅤ✦ㅤ ᴘʀᴇᴍɪᴜᴍ: ${isPremium ? 'Yes':'No'}
│ㅤ✧ㅤ ʜɪᴛ ᴄᴍᴅ: ${userdb.hitcmd}
│
│ㅤ✦ㅤ ᴜᴘʟᴏᴀᴅ: ${upload}
│ㅤ✧ㅤ ᴅᴏᴡɴʟᴏᴀᴅ: ${download}
│ㅤ✧ㅤ ɴᴏᴅᴇᴊꜱ ᴠᴇʀꜱɪᴏɴ: ${process.version}
│ㅤ✧ㅤ ᴠᴇʀꜱɪᴏɴ: 1.2
│ㅤ✦ㅤ ᴡʜɪꜱᴋᴇʏꜱᴏᴄᴋᴇᴛꜱ: custom: 6.6.0
│
╙─━─• *\`⟨  ＢＯＴ － ＣＬＩＥＮＴ  ⟩\`*`
async function tiktok2(query) {
  return new Promise(async (resolve, reject) => {
    try {
    const encodedParams = new URLSearchParams();
encodedParams.set('url', query);
encodedParams.set('hd', '1');
        
        //fake qute
        
        


      const response = await axios({
        method: 'POST',
        url: 'https://tikwm.com/api/',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Cookie': 'current_language=en',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
        },
        data: encodedParams
      });
      const videos = response.data.data;
        const result = {
          title: videos.title,
          cover: videos.cover,
          origin_cover: videos.origin_cover,
          no_watermark: videos.play,
          watermark: videos.wmplay,
          music: videos.music
        };
        resolve(result);
    } catch (error) {
      reject(error);
    }
  });
}
async function downloadyt(urlnyu, mpbrp) {
//  try {
    if (mpbrp === "mp3") {
    try {  
        try {               
                console.log("Mengunduh audio dari URL:", convert.url);
                audioUrl = await youtube(urlnyu);
            } catch (e) {             
                console.error("Error saat mengunduh, mencoba kembali...", e);
                reply('Please wait...');
                audioUrl = await youtube(urlnyu);
            }
            console.log("URL yang berhasil diunduh:", audioUrl);
    let doc = {
        audio: {
            url: audioUrl.mp3
        },
        mimetype: 'audio/mp4',
        fileName: "yang lu donlot tadi, "+hariini 
    };
    return ptz.sendMessage(m.chat, doc, { quoted: fsaluran });
      } catch {
        var wvhfy6tfe = await fetchJson("https://widipe.com/download/ytdl?url="+urlnyu)    
            let doc = {
        audio: {
            url: wvhfy6tfe.result.mp3
        },
        mimetype: 'audio/mp4',
        fileName: "yang lu donlot tadi, "+hariini 
    };
    return ptz.sendMessage(m.chat, doc, { quoted: fsaluran });
     }
    } else if (mpbrp === "mp4") {  
    try { 
         try {
                    console.log("Mengunduh audio dari URL:", convert.url);
                vidUrl = await youtube(urlnyu);
            } catch (e) {        
                console.error("Error saat mengunduh, mencoba kembali...", e);
                reply('Please wait...');
                vidUrl = await youtube(urlnyu);
            }
            console.log("URL yang berhasil diunduh:", vidUrl);
    return ptz.sendMessage(m.chat, {
  video: { url: vidUrl.mp4 },
 caption: `Done`, 
 }, {quoted: fsaluran })
} catch {
   var wvhfy6tc76gfe = await fetchJson("https://widipe.com/download/ytdl?url="+urlnyu)
 return ptz.sendMessage(m.chat, {
video: { url: wvhfy6tc76gfe.mp4 },
 caption: `Done`, 
 }, {quoted: fsaluran })
}
    } else {
      reply("Format tidak didukung.");
    }
}
async function kata2() {
var resio = await Quotes()
return `${resio.quotes}`
}
const katakata = await kata2()
if (settingdb.restart) {
try {
ptz.sendMessage(chatdb.lastchat, {text: "*Succes Restart bot-*"})
settingdb.restart = false
} catch(e) {
console.log(e)
}}
const getcomandces = (cases) => {
    try {
        const fileContent = fs.readFileSync('./case.js').toString();
        let caseContent = fileContent.split(`case '${cases}'`);    
        if (caseContent.length === 1) { 
            caseContent = fileContent.split(`case "${cases}"`);
        }
        if (caseContent.length > 1) {
            return "case " + `'${cases}'` + caseContent[1].split("break")[0] + "break";
        } else {
            return "none"; 
        }
    } catch (e) {
        return "none";
    }
};

  if (m.message && m.isGroup) {
      console.log(`\n< ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ >\n`)
     console.log(chalk.magenta(`Group Chat:`))
         console.log(chalk.black(chalk.bgWhite('[ MESSAGE ]')), chalk.white(chalk.bgMagenta(new Date)), chalk.black(chalk.bgWhite(budy || m.mtype)) + '\n' + chalk.white('=> From'), chalk.magenta(pushname), chalk.magenta(m.sender) + '\n' + chalk.white('=> In'), chalk.magenta(groupName, m.chat))
        } else {
            console.log(`\n< ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ >\n`)
			console.log(chalk.magenta(`Private Chat:`))
            console.log(chalk.black(chalk.bgWhite('[ MESSAGE ]')), chalk.white(chalk.bgMagenta(new Date)), chalk.black(chalk.bgWhite(budy || m.mtype)) + '\n' + chalk.white('=> From'), chalk.magenta(pushname), chalk.magenta(m.sender))
        }
        
 async function totalfiturr() {
   const fitur1 = () =>{
            var mytext = fs.readFileSync("./case.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length
            return numUpper
        }
   const fitur2 = () =>{
            var mytext = fs.readFileSync("./case.js").toString()
            var numUpper = (mytext.match(/case "/g) || []).length
            return numUpper
        }
 valvul = `${fitur1()} + ${fitur2()}`
.replace(/[^0-9\-\/+*×÷πEe()piPI/]/g, '')
.replace(/×/g, '*')
.replace(/÷/g, '/')
.replace(/π|pi/gi, 'Math.PI')
.replace(/e/gi, 'Math.E')
.replace(/\/+/g, '/')
.replace(/\++/g, '+')
.replace(/-+/g, '-')
let format = valvul
.replace(/Math\.PI/g, 'π')
.replace(/Math\.E/g, 'e')
.replace(/\//g, '÷')
.replace(/\*×/g, '×')
try {

let resulto = (new Function('return ' + valvul))()
if (!resulto) throw resulto
return resulto
} catch (e) {
if (e == undefined) return 
console.log("!")
}
}
const totalfitur = await totalfiturr()
async function kirimstik(linknya) {
ptz.sendVideoAsSticker(m.chat, linknya, fsaluran, { packname: '\n'.repeat(999)})
}
let list = []
for (let i of newowner) {
list.push({
displayName: await ptz.getName(i + '@s.whatsapp.net'),
vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await ptz.getName(i + '@s.whatsapp.net')}\n
FN:${await ptz.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET:ziooedt@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:https://digimon.wiki
item3.X-ABLabel:YouTube\n
item4.ADR:;;Indonesia;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
})
}
let listprem = []
for (let i of prem) {
list.push({
displayName: await ptz.getName(i + '@s.whatsapp.net'),
vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await ptz.getName(i + '@s.whatsapp.net')}\n
FN:${await ptz.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET:ziooedt@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:https://digimon.wiki
item3.X-ABLabel:YouTube\n
item4.ADR:;;Indonesia;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
})
}
   const reactmess = async(type) => {
          ptz.sendMessage(m.chat, {
            'react': {
              'text': type,
              'key': m.key
            }
          });
  }
    const randomNomor = async(ext) => {
    return `${Math.ceil(Math.random() * ext)}`
}
if (budy.match(`njing|onyet|etan|oblog|atim|ngentot|mek|ntol|asu|coli|sange|bot goblog|ngewe|njing|nying|nyet|tobrut|pixiv|furry|sex|xnxx|porn|porno|bokep|crot|ngocok|bolong|sabun|goyang|pantat|mani|pokemon|raimbow|lgbt|memek|pmo|duar`)) {
return kirimstik("https://cdn.meitang.xyz/file/BQACAgUAAxkDAAJt7mbladkvWSboinIrt7-I4NVWjJYnAAJ-FQACCY0xV4hCNWc9IaVeNgQ")
 }
if ((budy.match) && ["Assalamualaikum", "assalamualaikum", "Assalamu'alaikum","alaikum"].includes(budy) && !isCmd) {
reply("*Waalaikumsalam*")
}
if ((budy.match) && ["hai","ola","Halo","halo","alo"].includes(budy) && !isCmd) {
reply(`*Iya ?*`)
}
if ((budy.match) && ["Makasih", "thaks", "tq", "Terimakasih","akasih","hask"].includes(budy) && !isCmd) {
if (!m.quoted && !m.fromMe) return
reply(`*Ya*`)
}
if ((budy.match) && ["wkwk", "haha","bjir","jir","wow","keren"].includes(budy) && !isCmd) {
//reply(`_?_`)
return reactmess("🤔")
}
if ((budy.match) && ["P", "p",].includes(budy) && !isCmd) {
if (budy.length === 1) {
reply(`*Waalaikumsalam*`) 
} else {
}}
if ((budy.match) && ["Start", "mulai","bot"].includes(budy) && !isCmd) {
reply(`Silahlan Ketik .menu`)
}
if (!ptz.public) {
if (!m.key.fromMe && !isCreator) return
}
for (let jid of mentionUser) {
let user = global.db.data.users[jid]
if (!user) continue
let afkTime = user.afkTime
if (!afkTime || afkTime < 0) continue
let reason = user.afkReason || ''
reply(`*\`[ Jangan tag dia! ]\`*

Dia sedang AFK ${reason ? 'dengan alasan ' + reason : 'tanpa alasan'}
Selama ${clockString(new Date - afkTime)}
`.trim())
}
let tebaklagu = db.data.game.tebaklagu = []
let kuismath = db.data.game.kuismath = []
let tebakgambar = db.data.game.tebakgambar = []
let tebakkata = db.data.game.tebakkata = []
let tebakkalimat = db.data.game.tebakkalimat = []
let tebaklirik = db.data.game.tebaklirik = []
let tebaktebakan = db.data.game.tebaktebakan = []
let tebakbendera = db.data.game.tebakbendera = []
let tebakbendera2 = db.data.game.tebakbendera2 = []
let tebakkimia = db.data.game.tebakkimia = []
let tebakasahotak = db.data.game.tebakasahotak = []
let tebaksiapakahaku = db.data.game.tebaksiapakahaku = []
let tebaksusunkata = db.data.game.tebaksusunkata = []
let tebaktekateki = db.data.game.tebaktekateki = []
let caklontong = db.data.game.lontong = []
let caklontong_desk = db.data.game.lontong_desk = []
this.game = this.game ? this.game : {}
let room = Object.values(this.game).find(room => room.id && room.game && room.state && room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state == 'PLAYING')
if (room) {
let ok
let isWin = !1
let isTie = !1
let isSurrender = !1
// reply(`[DEBUG]\n${parseInt(m.text)}`)
if (!/^([1-9]|(me)?nyerah|surr?ender|off|skip)$/i.test(m.text)) return
isSurrender = !/^[1-9]$/.test(m.text)
if (m.sender !== room.game.currentTurn) { // nek wayahku
if (!isSurrender) return !0
}
if (!isSurrender && 1 > (ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1))) {
reply({
'-3': 'Game telah berakhir',
'-2': 'Invalid',
'-1': 'Posisi Invalid',
0: 'Posisi Invalid',
}[ok])
return !0
}
if (m.sender === room.game.winner) isWin = true
else if (room.game.board === 511) isTie = true
let arr = room.game.render().map(v => {
return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
}[v]
})
if (isSurrender) {
room.game._currentTurn = m.sender === room.game.playerX
isWin = true
}
let winner = isSurrender ? room.game.currentTurn : room.game.winner
let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

*[ ${isWin ? `@${winner.split('@')[0]} Menang!` : isTie ? `Game berakhir` : `Giliran ${['❌', '⭕'][1 * room.game._currentTurn]} (@${room.game.currentTurn.split('@')[0]})`} ]*

❌: @${room.game.playerX.split('@')[0]}
⭕: @${room.game.playerO.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== from)
room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = from
if (room.x !== room.o) await ptz.sendText(room.x, str, m, { mentions: parseMention(str) } )
await ptz.sendText(room.o, str, m, { mentions: parseMention(str) } )
if (isTie || isWin) {
delete this.game[room.id]
}
}
this.suit = this.suit ? this.suit : {}
let roof = Object.values(this.suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
if (roof) {
let win = ''
let tie = false
if (m.sender == roof.p2 && /^(acc(ept)?|terima|gas|oke?|tolak|gamau|nanti|ga(k.)?bisa|y)/i.test(m.text) && m.isGroup && roof.status == 'wait') {
if (/^(tolak|gamau|nanti|n|ga(k.)?bisa)/i.test(m.text)) {
ptz.sendTextWithMentions(from, `@${roof.p2.split`@`[0]} menolak suit, suit dibatalkan`, m)
delete this.suit[roof.id]
return !0
}
roof.status = 'play'
roof.asal = from
clearTimeout(roof.waktu)
//delete roof[roof.id].waktu
ptz.sendText(from, `Suit telah dikirimkan ke chat

@${roof.p.split`@`[0]} dan 
@${roof.p2.split`@`[0]}

Silahkan pilih suit di bot.`, m, { mentions: [roof.p, roof.p2] })
if (!roof.pilih) ptz.sendText(roof.p, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
if (!roof.pilih2) ptz.sendText(roof.p2, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
roof.waktu_milih = setTimeout(() => {
if (!roof.pilih && !roof.pilih2) ptz.sendText(from, `Kedua pemain tidak niat main,\nSuit dibatalkan`)
else if (!roof.pilih || !roof.pilih2) {
win = !roof.pilih ? roof.p2 : roof.p
ptz.sendTextWithMentions(from, `@${(roof.pilih ? roof.p2 : roof.p).split`@`[0]} tidak memilih suit, game berakhir`, m)
}
delete this.suit[roof.id]
return !0
}, roof.timeout)
}
let jwb = m.sender == roof.p
let jwb2 = m.sender == roof.p2
let g = /gunting/i
let b = /batu/i
let k = /kertas/i
let reg = /^(gunting|batu|kertas)/i
if (jwb && reg.test(m.text) && !roof.pilih && !m.isGroup) {
roof.pilih = reg.exec(m.text.toLowerCase())[0]
roof.text = m.text
reply(`Kamu telah memilih ${m.text} ${!roof.pilih2 ? `\n\nMenunggu lawan memilih` : ''}`)
if (!roof.pilih2) ptz.sendText(roof.p2, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
}
if (jwb2 && reg.test(m.text) && !roof.pilih2 && !m.isGroup) {
roof.pilih2 = reg.exec(m.text.toLowerCase())[0]
roof.text2 = m.text
reply(`Kamu telah memilih ${m.text} ${!roof.pilih ? `\n\nMenunggu lawan memilih` : ''}`)
if (!roof.pilih) ptz.sendText(roof.p, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
}
let stage = roof.pilih
let stage2 = roof.pilih2
if (roof.pilih && roof.pilih2) {
clearTimeout(roof.waktu_milih)
if (b.test(stage) && g.test(stage2)) win = roof.p
else if (b.test(stage) && k.test(stage2)) win = roof.p2
else if (g.test(stage) && k.test(stage2)) win = roof.p
else if (g.test(stage) && b.test(stage2)) win = roof.p2
else if (k.test(stage) && b.test(stage2)) win = roof.p
else if (k.test(stage) && g.test(stage2)) win = roof.p2
else if (stage == stage2) tie = true
ptz.sendText(roof.asal, `_*Hasil Suit*_${tie ? '\nSERI' : ''}

@${roof.p.split`@`[0]} (${roof.text}) ${tie ? '' : roof.p == win ? ` Menang \n` : ` Kalah \n`}
@${roof.p2.split`@`[0]} (${roof.text2}) ${tie ? '' : roof.p2 == win ? ` Menang \n` : ` Kalah \n`}
`.trim(), m, { mentions: [roof.p, roof.p2] })
delete this.suit[roof.id]
}
}
this.petakbom = this.petakbom ? this.petakbom : {}
let pilih = "🌀", bomb = "💣";
if (m.sender in this.petakbom) {
    if (!/^[1-9]$|^10$/i.test(body) || isCmd) return;
    const pos = parseInt(body) - 1;
    const gameData = this.petakbom[m.sender];
    const { petak, board, pick, nyawa, bomb, lolos } = gameData;
    if (petak[pos] === 1) return;  
    if (petak[pos] === 2) {
        gameData.board[pos] = bomb;
        gameData.pick++;
        ptz.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        gameData.bomb--;
        gameData.nyawa.pop();

        if (gameData.nyawa.length < 1) {
            await reply(`*GAME TELAH BERAKHIR*\nKamu terkena bomb\n\n${board.join("")}\n\n*Terpilih :* ${gameData.pick}\n*Pengurangan Bits :* -100`);
            delete this.petakbom[m.sender];
        } else {
            await reply(`*PILIH ANGKA*\n\nKamu terkena bomb\n${board.join("")}\n\nTerpilih: ${gameData.pick}\nSisa nyawa: ${gameData.nyawa.join("")}`);
        }
        return;
    }
    if (petak[pos] === 0) {
        gameData.petak[pos] = 1;
        gameData.board[pos] = pilih;
        gameData.pick++;
        gameData.lolos--;
        if (gameData.lolos < 1) {
            await reply(`\`*[ KAMU MENANG ]\`*\n\n${board.join("")}\n\n*Terpilih :* ${gameData.pick}\n*Sisa nyawa :* ${gameData.nyawa.join("")}\n*Bomb :* ${gameData.bomb}`);
            userdb.petakbom = false
            ptz.sendMessage(m.chat, { react: { text: '🟢', key: m.key } });
            delete this.petakbom[m.sender];
        } else {
            await reply(`*PILIH ANGKA*\n\n${board.join("")}\n\nTerpilih : ${gameData.pick}\nSisa nyawa : ${gameData.nyawa.join("")}\nBomb : ${gameData.bomb}`);
        }
        return;
    }
}
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}     
function cekJadibotEx() {
    const Jsonjadibot1 = './lib/json/jadibot.json';
    if (!fs.existsSync(Jsonjadibot1)) return;
    const jadibotJson1 = JSON.parse(fs.readFileSync(Jsonjadibot1, 'utf-8'));
    const now1 = new Date();
    Object.keys(jadibotJson1).forEach(chatId => {
        const targetTime = new Date(jadibotJson1[chatId].targetTime);
        if (chatId === ptz.decodeJid(ptz.user.id)) return;
        if (now1 >= targetTime) {
            ptz.sendMessage(chatId, { 
                text: 'Memasuki Tanggal Expire - session jadibot telah ter Suspend, ambil sessionmu atau renew!' 
            });
            delete jadibotJson1[chatId];
            fs.writeFileSync(Jsonjadibot1, JSON.stringify(jadibotJson1, null, 2));
        }
    });
}
const addTimeJadibot = (chatId, additionalHours) => {
  const Jsonjadibotn = './lib/json/jadibot.json';
    const jadibotJson = JSON.parse(fs.readFileSync(Jsonjadibotn, 'utf-8'));
    if (!jadibotJson[chatId]) {
        reply(`ID ${chatId} tidak ada di database, Silahkan Jadibot atau renew !`);
        return;
    }
    const currentTargetTime = new Date(jadibotJson[chatId].targetTime);
    const newTargetTime = new Date(currentTargetTime.getTime() + additionalHours * 60 * 60 * 1000);
    jadibotJson[chatId].targetTime = newTargetTime.getTime();
    fs.writeFileSync(Jsonjadibotn, JSON.stringify(jadibotJson, null, 2));
    const hours = Math.floor(additionalHours);
    const minutes = Math.floor((additionalHours % 1) * 60);
    const formattedTime = newTargetTime.toLocaleString();
    reply(`*${X}「 Waktu Expire Bot 」${X}*\n\nWaktu untuk ID ${chatId} berhasil diperpanjang!\n\nTambahan: ${hours} jam ${minutes} menit\nWaktu Expire Baru: ${formattedTime}`);
};
if (chatdb.mute && !isAdmins && !isCreator) {
      return
      }        
   if (!m.isGroup && !isCreator && settingdb.onlygrub ) {
	if (isCmd){
    return;
    }
}
if (!isCreator && settingdb.onlypc && m.isGroup) {
	if (isCmd){
	 return;
  }
}
//===============
setInterval(() => {
    cekJadibotEx();
}, 10000);







switch(command) {
//=============[ MAIN - MENU ]=================//
case 'everyone': 
 ptz.sendMessage(m.chat, {
text: "@" + m.chat,
contextInfo: {
groupMentions: [
{
groupJid: m.chat,
groupSubject: 'kijo suka loli'
}
]
}
}
)
break

case "repo":
case "sc":
case "script": {
    // React to the message with an emoji
    await ptz.sendMessage(m.chat, { react: { text: `🧩`, key: m.key } });

    // Define the message text
    const xtexg = `*\`乂 SCRIPT 乂\`*\n\nHey *${pushname}* 💚\n\n• Premium Subscription Only\n\n• If you want to Buy ❔\n\nContact *wa.me/94764497078*`;

    // Send a document with additional details
    await ptz.sendMessage(m.chat, {
        document: fs.readFileSync("./package.json"), // Read the file
        fileLength: 1000000000000, // Set file length (arbitrary large number)
        pageCount: 999, // Set page count
        fileName: 'Switch-Blade', // Set file name
        mimetype: 'application/msword', // Set MIME type
        jpegThumbnail: fs.readFileSync("./lib/Image/doc2.jpg"), // Set thumbnail
        caption: xtexg, // Set caption
        footer: 'Sandarux', // Set footer
        buttons: [
            {
                buttonId: `.ok`, // Button ID
                buttonText: { displayText: 'Ok' } // Button text
            }
        ],
        headerType: 1, // Set header type
        viewOnce: true, // Make it a view-once message
        contextInfo: {
            mentionedJid: [m.sender], // Mention the sender
            isForwarded: true // Mark as forwarded
        }
    }, { quoted: fsaluran }); // Quote the original message

    break;
}

case "menu": {
    await ptz.sendMessage(m.chat, { react: { text: `🎀`, key: m.key } });
    const xtexg = `*\`乂 Main Menu 乂\`* \n
┏❐
┃⭔.alive
┃⭔.ping
┃⭔.info
┃⭔.owner
┃⭔.panel
┗❐
${readmore}
*\`乂 Download Menu 乂\`* \n
┏❐  
┃⭔.video
┃⭔.ytmp3
┃⭔.ytmp4
┃⭔.ringtone
┃⭔.ig
┃⭔.song
┃⭔.fb
┃⭔.sticker
┃⭔.tiktok
┃⭔.ttmp3
┗❐

*\`乂 Owner Menu 乂\`* \n
┏❐  
┃⭔.self
┃⭔.public
┃⭔.addprem
┃⭔.delprem
┃⭔.onlygc
┃⭔.block
┃⭔.addowner
┃⭔.delowner
┃⭔.onlypc
┗❐

*\`乂 Group Menu 乂\`* \n
┏❐  
┃⭔.kick
┃⭔.add
┃⭔.promote
┃⭔.demote
┗❐

*\`乂 Search Menu 乂\`* \n
┏❐  
┃⭔.yts
┗❐

*\`乂 Tools Menu 乂\`* \n
┏❐  
┃⭔.shorty
┃⭔.shrinkme
┃⭔.savetxt
┃⭔.ss
┃⭔.aimage
┃⭔.fancy
┃⭔.anime
┃⭔.tme
┃⭔.tgs
┃⭔.github
┗❐

`;

    ptz.sendMessage(m.chat, {
        document: fs.readFileSync("./package.json"),
        fileLength: 100000000, 
        pageCount: 999, 
        fileName: 'Switch-Blade',
        mimetype: 'application/msword',
        jpegThumbnail: fs.readFileSync("./lib/Image/doc2.jpg"),
        caption: xtexg,
        footer: 'Sandarux',
        buttons: [
            {
                buttonId: `.info`,
                buttonText: { displayText: 'Info' }
            },
            {
                buttonId: `.owner`,
                buttonText: { displayText: 'Owner' }
            }
        ],
        headerType: 1,
        viewOnce: true,
        contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            externalAdReply: {
                title: "Simple Wa-bot",
                body: "Click here",
                showAdAttribution: true,
                thumbnail: fs.readFileSync('./lib/Image/doc.jpg'),
                mediaType: 1,
                previewType: 0,
                renderLargerThumbnail: true,
                sourceUrl: "https://www.youtube.com/@SANDARU-YT",
                mediaUrl: "https://www.youtube.com/@SANDARU-YT",
            },
        },
    }, { quoted: fsaluran });

    break;
}




case"info":case"infobot": case "credit":{
    ptz.sendMessage(m.chat, {

      text: `┏❐  ⌜ *I N F O* ⌟  ❐

•Helper  - Nimesh Piyumal

*https://github.com/nimesh-piyumal*

•Owner - Sandaru Nethsara

*https://github.com/sandaru-nethsara*

┏❐  ⌜ Donate Us ⌟  ❐

Buy me Coffee 🩵

*https://buymeacoffee.com/nimeshpiyumal*


┏❐  ⌜ Groups ⌟  ❐

Join Support ❔

*https://whatsapp.com/channel/0029VawMiVT9Gv7NTdq9jB1e*
`,
      footer: "©copyright by Sandarux",
      buttons: [
              { buttonId: `.menu`,
              buttonText: {
              displayText: 'Back'
              },
               type: 1 }
              ], // isi buttons nya
      headerType: 6,
      viewOnce: true
    }, { quoted: m });
    }
    //D|ts si pler 🐎
    break 









//=============[ Common - Feature ]=================//


case "owner":
    {
      await ptz.sendMessage(m.chat, { react: { text: `👤`, key: m.key } });
      const vcard =
        "BEGIN:VCARD\n" +
        "VERSION:3.0\n" +
        "FN:Sandaru \n" +
        "ORG:Owner;\n" +
        "TEL;type=CELL;type=VOICE;waid=94764497078:+94772797288\n" +
        "END:VCARD";

      

      await ptz.sendMessage(
        m.chat,
        { contacts: { displayName: "Gay", contacts: [{ vcard }] } },
        { quoted: fsaluran }
      );
    }
    break;   
   

//=============[ DOWNLOADER ]=================//  



  
      case 'git': case 'gitclone': case 'downgit':
if (!args[0]) return reply(`Link Nya Mana Kak?\nContoh :\n${prefix}${command} Link Github`)
if (!isUrl(args[0]) && !args[0].includes('github.com')) return reply(`Link invalid!!`)
let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
    let [, user, repo] = args[0].match(regex1) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    ptz.sendMessage(m.chat, { document: { url: url }, fileName: filename+'.zip', mimetype: 'application/zip' }, { quoted: fsaluran }).catch((err) =>(err))
break



//=============[ SEARCHER ]=================//
case 'yts': case 'ytsearch': {
    await ptz.sendMessage(m.chat, { react: { text: `🔍`, key: m.key } });
             if (!text) return reply(`Example : Oai Cat`)
             let yts = require("yt-search")
             let search = await yts(text)
             let teks = 'YouTube Search\n\n Result From '+text+'\n\n'
             let no = 1
             for (let i of search.all) {
                 teks += ` No : ${no++}\n Type : ${i.type}\n Video ID : ${i.videoId}\n Title : ${i.title}\n Views : ${i.views}\n Duration : ${i.timestamp}\n Uploaded : ${i.ago}\nUrl : ${i.url}\n\n─────────────────\n\n`
             }
             ptz.sendMessage(m.chat, { image: { url: search.all[0].thumbnail },  caption: teks }, { quoted: fsaluran })
         }
         break



         case 'play': case 'song': {
    if (!text) return reply("Example: Lelena")

    await ptz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } }) 
    
    try {
        const yts = require("yt-search")
        const search = await yts(text)
        const videos = search.videos
        if (!videos || videos.length === 0) return reply("Errr")

        const vid = videos[0] 
        const caption = `「 *\`Youtube Play\`* 」\n\n` +
            `💬 Title : ${vid.title}\n\n` +
            `📺 Views : ${vid.views}\n\n` +
            `⏰ Duration : ${vid.timestamp}\n\n` +
            `▶️ Channel : ${vid.author.name}\n\n` +
            `📆 Upload : ${vid.ago}\n\n` +
            `🔗 Url : ${vid.url}`

        await ptz.sendMessage(m.chat, {
            image: { url: vid.thumbnail },
            caption: caption,
            footer: `Sandarux`,
            buttons: [
                {
                    buttonId: `.ytmp3 ${vid.url}`,
                    buttonText: { displayText: "Audio" }
                },
                {
                    buttonId: `.ytmp3doc ${vid.url}`,
                    buttonText: { displayText: "Document" }
                },
            ],
            viewOnce: true,
        }, { quoted: fsaluran })

    } catch (error) {
        console.error(error)
        reply("❌ Error: Tikak passe try karanna")
    }

    break
}


  case 'video': case 'ytv': {
    if (!text) return reply("Example: Lelena")

    await ptz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } }) 
    
    try {
        const yts = require("yt-search")
        const search = await yts(text)
        const videos = search.videos
        if (!videos || videos.length === 0) return reply("Errr")

        const vid = videos[0] 
        const caption = `「 *\`Youtube Play\`* 」\n\n` +
            `💬 Title : ${vid.title}\n\n` +
            `📺 Views : ${vid.views}\n\n` +
            `⏰ Duration : ${vid.timestamp}\n\n` +
            `▶️ Channel : ${vid.author.name}\n\n` +
            `📆 Upload : ${vid.ago}\n\n` +
            `🔗 Url : ${vid.url}`

        await ptz.sendMessage(m.chat, {
            image: { url: vid.thumbnail },
            caption: caption,
            footer: `Sandarux`,
            buttons: [
                {
                    buttonId: `.ytmp4 ${vid.url}`,
                    buttonText: { displayText: "Video" }
                },
                {
                    buttonId: `.ytmp4doc ${vid.url}`,
                    buttonText: { displayText: "Document" }
                },
            ],
            viewOnce: true,
        }, { quoted: fsaluran })

    } catch (error) {
        console.error(error)
        reply("❌ Error: Tikak passe try karanna")
    }

    break
}



case "ytmp3": {
    if (!text) return reply("Please provide a name or YouTube URL.")

    await ptz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } })

    try {
        const url = `https://apis-sandarux.zone.id/api/ytmp3/ytdown?url=${encodeURIComponent(text)}`
        const { data } = await axios.get(url)

        if (data?.status) {
            const dlLink = data.result?.download_url 
                || data.result?.media?.find(m => m.Type === "audio" && m.format === "mp3")?.download_link

            if (!dlLink) return reply("❌ Audio link not found.")

            await ptz.sendMessage(
                m.chat,
                {
                    audio: { url: dlLink },
                    mimetype: "audio/mpeg",
                      contextInfo: {
                            forwardingScore: 9999999,
                            isForwarded: true,
                        }
                    
                },
                { quoted: m }
            )

            await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
            return
        } else {
            reply("❌ Failed to fetch audio from API.")
        }

    } catch (error) {
        console.error("Error fetching YouTube MP3:", error)
        reply("❌ Failed to fetch the song. Please try again later.")
    }

    break
}


case "ytmp4": {
        await ptz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } })

    if (!text) return reply("💡 Please provide a YouTube URL.\n\nExample: *.ytmp4 https://youtu.be/xxxx*");

    try {
        const mp4dl = await ytmp4(text, {
            format: "mp4",
            videoQuality: "720"
        });


        if (!mp4dl || !mp4dl.url) {
            return reply("❌ Failed to get the video. Please check the URL and try again.");
        }

        const videoBuffer = await (await fetch(mp4dl.url)).arrayBuffer();

        await ptz.sendMessage(m.chat, {
            video: Buffer.from(videoBuffer),
            caption: `🎬 ${mp4dl.filename}`,
            mimetype: "video/mp4"
        });

    } catch (err) {
        console.error("❌ Error sending video:", err.message);
        return reply("❌ Error downloading/sending the video.");
    }
}
break;





case "ytmp3doc": {
    if (!text) return reply("Please provide a YouTube URL.")

    await ptz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } })

    try {
        const url = `https://apis-sandarux.zone.id/api/ytmp3/ytdown?url=${encodeURIComponent(text)}`
        const { data } = await axios.get(url)

        if (data?.status) {
            // handle ytmp3/ytdown structure
            const dlLink = data.result?.download_url 
                || data.result?.media?.find(m => m.Type === "audio" && m.format === "mp3")?.download_link

            if (!dlLink) return reply("❌ Audio link not found.")

            await ptz.sendMessage(
                m.chat,
                {
                    document: { url: dlLink },
                    mimetype: "audio/mpeg",
                    fileName: `${data.result.title}.mp3`,
                    contextInfo: {
                        externalAdReply: {
                            thumbnailUrl: data.result.thumbnail,
                            title: data.result.title,
                            body: "Switch-Blade MD",
                            sourceUrl: text,
                            renderLargerThumbnail: true,
                            mediaType: 1,
                            forwardingScore: 9999999,
                            isForwarded: true,
                        }
                    }
                },
                { quoted: m }
            )

            await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
            return
        } else {
            reply("❌ Failed to fetch audio from API.")
        }

    } catch (error) {
        console.error("Error fetching YouTube Document:", error)
        reply("❌ Failed to fetch the song. Please try again later.")
    }

    break
}


case "ytmp4doc": {

        await ptz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } })

    if (!text) return reply("💡 Please provide a YouTube URL.\n\nExample: *.ytmp4 https://youtu.be/xxxx*");

    try {
        const mp4dl = await ytmp4(text, {
            format: "mp4",
            videoQuality: "720"
        });


        if (!mp4dl || !mp4dl.url) {
            return reply("❌ Failed to get the video. Please check the URL and try again.");
        }

        const videoBuffer = await (await fetch(mp4dl.url)).arrayBuffer();

        await ptz.sendMessage(m.chat, {
            document: Buffer.from(videoBuffer),
            filename: `${mp4dl.filename}.mp4`,
            caption: `🎬 ${mp4dl.filename}`,
            mimetype: "video/mp4"
        });

    } catch (err) {
        console.error("❌ Error sending video:", err.message);
        return reply("❌ Error downloading/sending the video.");
    }
}
break;


case "fb": {
    try {
        const url = args[0]; 
        if (!url) return m.reply("Please provide a Facebook video URL!");

        const apiResponse = await fetch(`https://www.sankavollerei.com/download/facebook?apikey=planaai&url=${encodeURIComponent(url)}`);
        const data = await apiResponse.json();

        if (!data.status) return m.reply("Failed to fetch video!");

        const sdVideo = data.result.video.find(v => v.quality.includes("360p"));
        if (!sdVideo) return m.reply("360p video not available.");

        await ptz.sendMessage(m.chat, {
            video: { url: sdVideo.url },
            caption: `*${data.result.title}*\nDuration: ${data.result.duration}`
        }, { quoted: m });

    } catch (err) {
        console.log(err);
        m.reply("Error fetching Facebook video.");
    }
    break;
}



case "tiktok":
case "tt": {
    if (!text) return reply("Please provide a TikTok video URL.")

    await ptz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } }) 

    try {
        const apiUrl = `https://apis-sandarux.zone.id/api/tiktok/tiktokdl?url=${encodeURIComponent(text)}`
        const { data } = await axios.get(apiUrl)

        if (!data || !data.status || !data.result) {
            return reply("❌ Failed to fetch TikTok video.")
        }

        const res = data.result

        const caption = `「 *TikTok Downloader* 」\n
🎵 Title: ${res.title}
👤 Author: ${res.caption || "Unknown"}
🌍 Region: ${res.region}
⏱ Duration: ${res.duration}s
👀 Views: ${res.stats.views}
❤️ Likes: ${res.stats.likes}
💬 Comments: ${res.stats.comment}
🔁 Shares: ${res.stats.share}`

        await ptz.sendMessage(
            m.chat,
            {
                video: { url: res.nowm },
                caption: caption,
                mimetype: "video/mp4",

            },
            { quoted: m }
        )

        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) // success

    } catch (e) {
        console.error("TikTok Error:", e)
        reply("❌ Failed to fetch TikTok video. Check console log.")
    }

    break
}



case "ttmp3": {
    if (!text) return reply("Please provide a TikTok video URL.")

    await ptz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } })

    try {
        const apiUrl = `https://apis-sandarux.zone.id/api/tiktok/tiktokdl?url=${encodeURIComponent(text)}`
        const { data } = await axios.get(apiUrl)

        if (!data || !data.status || !data.result) {
            return reply("❌ Failed to fetch TikTok audio.")
        }

        const res = data.result


        await ptz.sendMessage(
            m.chat,
            {
                audio: { url: res.music }, 
                mimetype: "audio/mpeg",
                fileName: `${res.title}.mp3`,
            },
            { quoted: m }
        )

        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) 

    } catch (e) {
        console.error("TikTok MP3 Error:", e)
        reply("❌ Failed to fetch TikTok audio. Check console log.")
    }

    break
}




    case "ytdoc": 
case "hgds": 
    if (!text) return reply("Please provide a name or YouTube URL.");

    await ptz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } }); // Processing reaction

    try {
        const { data } = await axios.get(`https://api.genux.me/api/download/ytmp3?query=${text}&apikey=GENUX-SANDARUX`);

        if (data.result.dl_links) {
            await ptz.sendMessage(
                m.chat, 
                { 
                    document: { url: data.result.dl_links }, 
                    fileName: data.result.title + '.mp3',
                    mimetype: "audio/mpeg",
                    contextInfo: {  
                        externalAdReply: {
                            thumbnailUrl: data.result.image,
                            title: data.result.title,
                            body: "Switch-Blade MD",
                            sourceUrl: data.result.author.url,
                            renderLargerThumbnail: true,
                            mediaType: 1,
                            forwardingScore: 9999999,
                            isForwarded: true,
                        }
                    }
                }, 
                { quoted: m }
            );

            await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return;
        } 
    } catch (error) {
        console.error("Error fetching YouTube MP3:", error);
        reply("❌ Failed to fetch the song. Please try again later.");
    }
    
    break;



      case "ss":
  {
    if (!text) return reply("Please provide a web url");
    await ptz.sendMessage(m.chat, { react: { text: '📖', key: m.key } });


    await ptz.sendMessage(
      m.chat,
      {
        image: {
          url: `https://apis-sandarux.zone.id/api/ss/ssweb?url=${encodeURIComponent(text)}`,
        },
      },
      { quoted: m }
    );
  }
  break;




  case "fancy": {
    if (!text) return reply("💡 Please provide text to style.\n\nExample: *.fancy Mother*")

    await ptz.sendMessage(m.chat, { react: { text: '✨', key: m.key } }) 

    try {
        const apiUrl = `https://apis-sandarux.zone.id/api/fancy/styletext?q=${encodeURIComponent(text)}`
        const { data } = await axios.get(apiUrl)

        if (!data || !data.status || !Array.isArray(data.result)) {
            return reply("❌ Failed to fetch styled text.")
        }

        let msg = `✨ *Fancy Text Generator* ✨\n\n`
        data.result.forEach((style) => {
            if (style.result) { 
                msg += `• *${style.name}*: ${style.result}\n`
            }
        })

        await ptz.sendMessage(
            m.chat,
            { text: msg },
            { quoted: m }
        )

        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) 
    } catch (e) {
        console.error("Fancy Text Error:", e)
        reply("❌ Something went wrong while fetching fancy text.")
    }

    break
}


case "anime": {
    await ptz.sendMessage(m.chat, { react: { text: '🎬', key: m.key } }) 

    try {
        const apiUrl = `https://apis-sandarux.zone.id/api/anime/animevideo`
        const { data } = await axios.get(apiUrl)

        if (!data || !data.status || !data.result || !data.result.download_link) {
            return reply("❌ Failed to fetch anime video.")
        }

        const videoUrl = data.result.download_link
        const caption = `🎬 *Anime Video*\n\n${data.result.title}`

        await ptz.sendMessage(
            m.chat,
            {
                video: { url: videoUrl },
                mimetype: "video/mp4",
                caption: caption,
              
            },
            { quoted: m }
        )

        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) // success
    } catch (e) {
        console.error("Anime Video Error:", e)
        reply("❌ Failed to fetch anime video. Check console log.")
    }

    break
}

case "github": {
    if (!text) return reply("💡 Please provide a GitHub username.\n\nExample: *.github nimesh-piyumal*")

    await ptz.sendMessage(m.chat, { react: { text: '🔍', key: m.key } }) 

    try {
        const apiUrl = `https://apis-sandarux.zone.id/api/stalk/github-stalk?user=${encodeURIComponent(text)}`
        const { data } = await axios.get(apiUrl)

        if (!data || !data.status || !data.result) {
            return reply("❌ Failed to fetch GitHub profile. Check the username.")
        }

        const user = data.result
        const caption = `
👤 Name: ${user.nickname || "N/A"}
🔗 Username: ${user.username}
💻 Profile: ${user.url}
🏢 Company: ${user.company || "N/A"}
📝 Bio: ${user.bio || "N/A"}
📍 Location: ${user.location || "N/A"}
📄 Public Repos: ${user.public_repo}
📦 Public Gists: ${user.public_gists}
👥 Followers: ${user.followers}
➡️ Following: ${user.following}
📅 Created: ${new Date(user.created_at).toLocaleDateString()}
        `

        await ptz.sendMessage(
            m.chat,
            {
                image: { url: user.profile_pic },
                caption: caption
            },
            { quoted: m }
        )

        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) 

    } catch (e) {
        console.error("GitHub Stalk Error:", e)
        reply("❌ Something went wrong while fetching the GitHub profile.")
    }

    break
}


case "tme": {
    if (!text) return reply("💡 Please provide a Telegram username.\n\nExample: *.tme Sandarufh*")

    await ptz.sendMessage(m.chat, { react: { text: '📱', key: m.key } }) 

    try {
        const apiUrl = `https://apis-sandarux.zone.id/api/tme/telegram?username=${encodeURIComponent(text)}`
        const { data } = await axios.get(apiUrl)

        if (!data || !data.status || !data.result) {
            return reply("❌ Failed to fetch Telegram profile.")
        }

        const res = data.result
        const caption = `Name: 👤 *${res.title}*\n\nAbout: ${res.description}\n\n🔗 [Open Telegram](${res.url})`

        await ptz.sendMessage(
            m.chat,
            {
                image: { url: res.image_url },
                caption: caption,
              
            },
            { quoted: m }
        )

        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) 

    } catch (e) {
        console.error("Telegram Profile Error:", e)
        reply("❌ Failed to fetch Telegram profile. Check console log.")
    }

    break
}



case "shorty": {
    if (!text) return reply("💡 Please provide a URL to shorten.\n\nExample: *.shorty https://example.com*")

    await ptz.sendMessage(m.chat, { react: { text: '✂️', key: m.key } }) 

    try {
        const apiUrl = `https://apis-sandarux.zone.id/api/shorty/shorturl?url=${encodeURIComponent(text)}`
        const { data } = await axios.get(apiUrl)

        if (!data || !data.status || !data.result) {
            return reply("❌ Failed to shorten the URL.")
        }

        const shortUrl = data.result

        await ptz.sendMessage(
            m.chat,
            { text: `✂️ Shortened URL:\n${shortUrl}` },
            { quoted: m }
        )

        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) // success

    } catch (e) {
        console.error("Shorty URL Error:", e)
        reply("❌ Something went wrong while shortening the URL.")
    }

    break
}


case "shrinkme": {
    if (!text) return reply("💡 Please provide a URL to shorten.\n\nExample: *.shrinkme https://example.com*")

    await ptz.sendMessage(m.chat, { react: { text: '✂️', key: m.key } }) 

    try {
        const apiUrl = `https://apis-sandarux.zone.id/api/shrinkme/shrinkme-short-url?url=${encodeURIComponent(text)}`
        const { data } = await axios.get(apiUrl)

        if (!data || !data.status || !data.result) {
            return reply("❌ Failed to shorten the URL.")
        }

        const originalUrl = data.result.original
        const shortUrl = data.result.shortened

        await ptz.sendMessage(
            m.chat,
            { text: `✂️ ShrinkMe URL Shortener\n\nOriginal: ${originalUrl}\nShortened: ${shortUrl}` },
            { quoted: m }
        )

        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) 

    } catch (e) {
        console.error("ShrinkMe URL Error:", e)
        reply("❌ Something went wrong while shortening the URL.")
    }

    break
}


case "savtxt": {
    if (!text) return reply("💡 Please provide the text to save.\n\nExample: *.savtxt Hello world*")

    await ptz.sendMessage(m.chat, { react: { text: '💾', key: m.key } }) 

    try {
        const apiUrl = `https://apis-sandarux.zone.id/api/genux/save-text?content=${encodeURIComponent(text)}`
        const { data } = await axios.get(apiUrl)

        if (!data || !data.status || !data.url) {
            return reply("❌ Failed to save the text.")
        }

        const savedUrl = data.url

        await ptz.sendMessage(
            m.chat,
            { text: `💾 Text saved successfully!\n\nYour link: ${savedUrl}` },
            { quoted: m }
        )

        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) 

    } catch (e) {
        console.error("Save Text Error:", e)
        reply("❌ Something went wrong while saving the text.")
    }

    break
}


case "tgs": {
    if (!text) return reply("💡 Please provide a search keyword.\n\nExample: *.tgs emoney*")

    await ptz.sendMessage(m.chat, { react: { text: '🔍', key: m.key } }) // processing reaction

    try {
        const apiUrl = `https://apis-sandarux.zone.id/api/tsearch/telegramgc-search?q=${encodeURIComponent(text)}`
        const { data } = await axios.get(apiUrl)

        if (!data || !data.status || !Array.isArray(data.results) || data.results.length === 0) {
            return reply("❌ No groups found for that keyword.")
        }

        let msg = `🔍 *Telegram Groups Search*\nKeyword: ${text}\n\n`
        data.results.forEach((group, i) => {
            msg += `*${i+1}. ${group.name}*\n`
            msg += `👥 Members: ${group.members}\n`
            msg += `📂 Category: ${group.category}\n`
            msg += `📝 Description: ${group.description}\n`
            msg += `🔗 Link: ${group.link}\n\n`
        })

        await ptz.sendMessage(
            m.chat,
            { text: msg },
            { quoted: m }
        )

        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) // success

    } catch (e) {
        console.error("Telegram Group Search Error:", e)
        reply("❌ Something went wrong while searching Telegram groups.")
    }

    break
}


case "ringtone": {
    if (!text) return reply("💡 Please provide a keyword to search ringtones.\n\nExample: *.ringtone eminem*")

    await ptz.sendMessage(m.chat, { react: { text: '🎵', key: m.key } }) 

    try {
        const apiUrl = `https://apis-sandarux.zone.id/api/ringtone/ringtonedl?q=${encodeURIComponent(text)}`
        const { data } = await axios.get(apiUrl)

        if (!data || !data.status || !Array.isArray(data.result) || data.result.length < 5) {
            return reply("❌ Not enough results found.")
        }

        for (let i = 0; i < 5; i++) {
            const ringtone = data.result[i]

            await ptz.sendMessage(
                m.chat,
                {
                    audio: { url: ringtone.audio },
                    mimetype: "audio/mpeg",
                    fileName: `${ringtone.title}.mp3`,
                  
                },
                { quoted: m }
            )

        }

        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) 

    } catch (e) {
        console.error("Ringtone Error:", e)
        reply("❌ Something went wrong while fetching ringtones.")
    }

    break
}


case "ig": {
    if (!text) return reply("💡 Please provide an Instagram URL.\n\nExample: *.ig https://www.instagram.com/reel/xxxx*")

    await ptz.sendMessage(m.chat, { react: { text: '🎬', key: m.key } }) 

    try {
        const apiUrl = `https://apis-sandarux.zone.id/api/ig/instagram?url=${encodeURIComponent(text)}`
        const { data } = await axios.get(apiUrl)

        if (!data || !data.status || !data.result || !data.result.url || !data.result.url[0]) {
            return reply("❌ Failed to fetch Instagram video. Check the URL.")
        }

        const videoUrl = data.result.url[0]

        await ptz.sendMessage(
            m.chat,
            {
                video: { url: videoUrl },
            },
            { quoted: m }
        )

        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) 

    } catch (e) {
        console.error("Instagram Download Error:", e)
        reply("❌ Something went wrong while fetching the Instagram video.")
    }

    break
}



case "aimage": {
    if (!text) return reply("💡 Please provide a prompt to generate an image.\n\nExample: *.aimage cat flying*")

    await ptz.sendMessage(m.chat, { react: { text: '🎨', key: m.key } }) 

    try {
        const apiUrl = `https://apis-sandarux.zone.id/api/aimage/text2img?prompt=${encodeURIComponent(text)}`
        const { data } = await axios.get(apiUrl)

        if (!data || !data.status || !data.image) {
            return reply("❌ Failed to generate image. Try again with a different prompt.")
        }

        await ptz.sendMessage(
            m.chat,
            {
                image: { url: data.image }
                        },
            { quoted: m }
        )

        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) 

    } catch (e) {
        console.error("AI Image Generation Error:", e)
        reply("❌ Something went wrong while generating the image.")
    }

    break
}




//=============[ OWNER - COMMAND ]=================//
case 'onlygroup':
case 'onlygc':
    if (!isCreator) return reply(mess.owner)
    if (args.length < 1) return reply(`Ex: ${prefix + command} on/off`)
    if (q == 'on') {
        settingdb.onlygc = true
        reply(`Successfully Changed Onlygroup To ${q}`)
    } else if (q == 'off') {
      settingdb.onlygc = false
        reply(`Successfully Changed Onlygroup To ${q}`)
    }
break
case 'onlyprivatechat':
case 'onlypc':
    if (!isCreator) return reply(mess.owner)
    if (args.length < 1) return reply(`Ex: ${prefix + command} on/off`)
    if (q == 'on') {
        settingdb.onlypc = true
        reply(`Successfully Changed Only-Pc To ${q}`)
    } else if (q == 'off') {
        settingdb.onlypc = false
        reply(`Successfully Changed Only-Pc To ${q}`)
    }
break
case 'mutegc':
if (!isCreator) return reply(mess.owner)
if (text === "on") {
chatdb.mute = true
reply(mess.done)
} else if (text === "off") {
chatdb.mute = false
reply(mess.done)
} else {
m.reply("on / off")
}
break

case 'join':
   if (!isCreator) return reply(mess.owner)
     if (!text) return reply('Enter Group Link!')      
        reply(mess.wait)
        let resultpew = args[0].split('https://chat.whatsapp.com/')[1]
      await ptz.groupAcceptInvite(resultpew).then((res) => reply(json(res))).catch((err) => reply(json(err)))
break      
case 'leave':
    if (!isCreator) return reply(mess.owner)
    if (!isGroup) {
    reply('*`[ Gumdramon ] Bye Everyone`*')
    await ptz.groupLeave(m.chat)
    } else {
    if (!text) return reply("`[ Gumdramon ] masukan id group`")
    reply('*`[ Gumdramon ] Bye Everyone`*', text)
    await ptz.groupLeave(text)
    reply(mess.done)
    }
    break
case 'block':
if (!isCreator) return reply(mess.owner)
let blockw = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
await ptz.updateBlockStatus(blockw, 'block').then((res) => reply(json(res))).catch((err) => reply(json(err)))
break
case 'unblock':
if (!isCreator) return reply(mess.owner)
let blockww = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
await ptz.updateBlockStatus(blockww, 'unblock').then((res) => reply(json(res))).catch((err) => reply(json(err)))
break
case 'banned':  {
if (!isCreator) return reply(mess.owner)
if (!args[0]) return reply(`*Contoh : ${command} add 6281214281312*`)
if (args[1]) {
orgnye = args[1] + "@s.whatsapp.net"
} else if (m.quoted) {
orgnye = m.quoted.sender
}
const isBane = banned.includes(orgnye)
if (args[0] === "add") {
if (isBane) return reply('*Pengguna Ini telah Di Ban*')
banned.push(orgnye)
reply(`Succes ban Pengguna Ini`)
} else if (args[0] === "del") {
if (!isBane) return reply('*Pengguna Ini Telah Di hapus Dari Ban*')
let delbans = banned.indexOf(orgnye)
banned.splice(delbans, 1)
reply(`*Berhasil Menghapus Pengguna yang Di Ban*`)
} else {
reply("Error")
}
}
break
case 'listban':
if (isBan) return reply('*Lu Di Ban Owner*')
 teksooop = `*List Ban*\n\n`
for (let ii of banned) {
teksooop += `- ${ii}\n`
}
reply(teksooop)
break
    case 'readchange': case 'autoread':{
if (!isCreator) return reply(mess.owner)   
if (args.length < 1) return reply(`Contoh ${prefix + command} on/off`)
if (q === 'on') {
global.autoread = true
reply(`Berhasil mengubah autoread ke ${q}`)
} else if (q === 'off') {
global.autoread = false
reply(`Berhasil mengubah autoread ke ${q}`)
}
}
break

    case 'delsession':
            case 'clearsession': {
                if (!isCreator) return reply(mess.owner)
                fs.readdir("./lib/system/session", async function(err, files) {
                    if (err) {
                        console.log('Unable to scan directory: ' + err);
                        return reply('Unable to scan directory: ' + err);
                    }
                    let filteredArray = await files.filter(item => item.startsWith("pre-key") ||
                        item.startsWith("sender-key") || item.startsWith("session-") || item.startsWith("app-state")
                    )
                    console.log(filteredArray.length);
                    let teks = `Bentar..`
                    if (filteredArray.length == 0) return reply(teks)
                    filteredArray.map(function(e, i) {
                        teks += (i + 1) + `. ${e}\n`
                    })
                    
                    
                    await filteredArray.forEach(function(file) {
                        fs.unlinkSync(`./lib/session/${file}`)
                    });
                    await sleep(2000)
                    reply("Sukses")
                });
            }
            break
        case 'getsession':
                if (!isCreator) return reply(mess.owner)
                
                let sessionbot2 = fs.readFileSync('./lib/system/session/creds.json')
                ptz.sendMessage(m.chat, {
                    document: sessionbot2,
                    mimetype: 'application/json',
                    fileName: 'creds.json'
                }, {
                    quoted: fsaluran
                })
            break          
            case "public":
         if (!isCreator) return reply(mess.owner)
        ptz.public = true 
        reply(mess.done)
        break
        
        case "self":
        if (!isCreator) return reply(mess.owner)
        ptz.public = false
        reply(mess.done)
        break
        
        case 'getcase':
 if (!isCreator) return reply(mess.owner)
if (!q) return reply(`Contoh penggunaan: ${prefix+command} menu`)
const getcase = (cases) => {
return "case "+`'${cases}'`+fs.readFileSync('./case.js').toString().split('case \''+cases+'\'')[1].split("break")[0]+"break"
}
reply(`${getcase(q)}`)
break
case 'listprem':{
ptz.sendMessage(m.chat, { 
contacts: { 
displayName: `${listprem.length} Contact`, 
contacts: list }, contextInfo: {
forwardingScore: 9999999, 
isForwarded: true,
mentionedJid: [m.sender],
forwardedNewsletterMessageInfo: {
            newsletterJid: global.idsaluran,
            serverMessageId: null,
            newsletterName: global.namesaluran
        },
}}, { quoted: fsaluran })
}
        break    
  case 'addowner': {
if (!isCreator) return reply(mess.owner)
if (!args[0]) return reply(` ${prefix+command} number\nEx ${prefix+command} 6831#####`)
prem1 = text.replace(/[^0-9]/g, '')
let cek1 = await ptz.onWhatsApp(prem1 + `@s.whatsapp.net`)
if (cek1.length == 0) return (`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
newowner.push(prem1)
fs.writeFileSync('./lib/json/owner.json', JSON.stringify(newowner))
reply(`*${prem1} Telah menjadi owner*`)
}
break
case 'delowner': {
if (!isCreator) return reply(mess.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6831#####`)
prem2 = text.replace(/[^0-9]/g, '')
unp = newowner.indexOf(prem2)
newowner.splice(unp, 1)
fs.writeFileSync('./lib/json/owner.json', JSON.stringify(newowner))
reply(`*${prem2} Tidak lagi Menjadi owner*`)
}
break
case 'delcase': {
 if (!isCreator) return reply(mess.owner)
 if (!text) return reply('Mana case yang ingin dihapus?');
 const namaFile = './case.js';
 const caseToDelete = `case '${text}':`;
 fs.readFile(namaFile, 'utf8', (err, data) => {
 if (err) {
 console.error('Terjadi kesalahan saat membaca file:', err);
 return reply('Terjadi kesalahan saat membaca file.');
 }
const posisiCase = data.indexOf(caseToDelete);
 if (posisiCase === -1) {
 return reply(`Case '${args}' tidak ditemukan dalam file.`);
 }
 const posisiBreak = data.indexOf('break;', posisiCase);
 if (posisiBreak === -1) {
 return reply('Tidak dapat menemukan "break;" setelah case yang ingin dihapus.');
 }
 const kodeBaruLengkap = data.slice(0, posisiCase) + data.slice(posisiBreak + 'break;'.length);
fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
 if (err) {
 console.error('Terjadi kesalahan saat menulis file:', err);
 return reply('Terjadi kesalahan saat menulis file.');
 } else {
 return reply(`Case '${text}' berhasil dihapus.`);
 }
 });
 });
    }
 break;
 case 'shutdown':
     if (!isCreator) return reply(mess.owner)
     reply(`*Bye bye !*`)
     await sleep(3000)
     process.exit(1)
     break
 case 'restart':
     if (!isCreator) return reply(mess.owner)
const restart = async() => {
     reply(mess.wait)
     settingdb.restart = true
     chatdb.lastchat = m.chat
}
  await restart()
     setTimeout(() => process.exit(), 2000)
     break
case "addprem":{
if (!isCreator) return reply(mess.owner)
if (!args[0]) return reply(`ex ${prefix+command} 9464449xxx`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await ptz.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Enter a valid number and register on WhatsApp!!!`)
prem.push(prrkek)
fs.writeFileSync("./lib/json/premium.json", JSON.stringify(prem))
reply(`User ${prrkek} Has Become Premium!`)
}
break
case "delprem":{
if (!isCreator) return reply(mess.owner)
if (!args[0]) return reply(`Use  ${prefix+command} number\nExample ${prefix+command} 947644970xx`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = prem.indexOf(ya)
prem.splice(unp, 1)
fs.writeFileSync("./lib/json/premium.json", JSON.stringify(prem))
reply(`Number ${ya} Has Been Removed Premium!`)
}    
        break

   
        


//=================================================//
case "add":{
if (m?.isGroup && !isAdmins && !isGroupOwner && isBotAdmins) return
if (!text && !m?.quoted) reply('Enter the number you want to add')
let users = m?.quoted ? m?.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await ptz.groupParticipantsUpdate(m?.chat, [users], 'add').catch(console.log)
}
break
//=================================================//
case "kick":{
if (m?.isGroup && !isAdmins && !isGroupOwner && isBotAdmins) return
if (!text && !m?.quoted) reply('Enter the number you want to kick')
let users = m?.quoted ? m?.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await ptz.groupParticipantsUpdate(m?.chat, [users], 'remove').catch(console.log)
}
break
//=================================================//
case "promote":{
if (m?.isGroup && !isAdmins && !isGroupOwner && isBotAdmins) return
if (!text && !m?.quoted) reply('Enter the number you want to promote')
let users = m?.quoted ? m?.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await ptz.groupParticipantsUpdate(m?.chat, [users], 'promote').catch(console.log)
}
break
//=================================================//
case "demote":{
if (m?.isGroup && !isAdmins && !isGroupOwner && isBotAdmins) return
if (!text && !m?.quoted) reply('Enter the number you want to demote')
let users = m?.quoted ? m?.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await ptz.groupParticipantsUpdate(m?.chat, [users], 'demote').catch(console.log)
}
break
//=================================================//
case "ai": {
    if (!text) return reply("💡 Please provide a question or text.\n\nExample: *.ai what is JavaScript?*")

    await ptz.sendMessage(m.chat, { react: { text: '🤖', key: m.key } }) // thinking reaction

    try {
        const apiUrl = `https://apis-sandarux.zone.id/api/ai/claude?text=${encodeURIComponent(text)}`
        const { data } = await axios.get(apiUrl)

        if (!data || !data.status || !data.response) {
            return reply("❌ Failed to fetch AI response.")
        }

        const botReply = `🤖 *AI Response*\n\n${data.response}`

        await ptz.sendMessage(
            m.chat,
            { text: botReply },
            { quoted: m }
        )

        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key } }) 
    } catch (e) {
        console.error("AI Command Error:", e)
        reply("❌ Something went wrong while fetching AI response.")
    }
    break
}



//=================================================//

 //=================================================//
 
 //=================================================//
 
 //=================================================//
 //=================================================//

 //=================================================//
 case 'sticker':
 case 'stiker':
 case 's': {
     if (!quoted) return reply(`reply Video/Image Dengan Caption ${prefix + command}`)
     if (/image/.test(mime)) {
         let media = await m?.quoted.download()
         let encmedia = await ptz.sendImageAsSticker(m?.chat, media, m, {
             packname: global.packname,
             author: global.author
         })
         await fs.unlinkSync(encmedia)
     } else if (/video/.test(mime)) {
         if ((quoted.msg || quoted).seconds > 11) return reply('Maksimal 10 detik!')
         let media = await quoted.download()
         let encmedia = await ptz.sendVideoAsSticker(m?.chat, media, m, {
             packname: global.packname,
             author: global.author
         })
         await fs.unlinkSync(encmedia)
     } else {
         return reply(`Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`)
     }
 }
 break
 //=================================================//
 
 //=================================================//

 //=================================================//
 case "bingimg-2d": {
     if (!text) return reply("[ ! ] masukan prompt gambar yang mau di bikin");
     let teksu = text.replace(/loli/gi, "anak gadis kecil");
     try {
         const {
             BingApi,
             apikeybing
         } = require('./lib/bing-image.js');
         const bingApi = new BingApi(apikeybing);
         const imagesUrls = await bingApi.createImages(teksu + ". Anime Style ultra, HD Anime Style, 4K Anime Style, Anime Style, High quality, Ultra grapics, HD Cinematic, anime, 4K resolution, HD quality, Ultra CGI, High quality, Ultra grapics, HD Cinematic", false);
         const totalCount = imagesUrls.length;
         const credits = await bingApi.getCredits();

         if (totalCount > 0) {
             for (let i = 0; i < totalCount; i++) {
                 try {
                     await new Promise(resolve => setTimeout(resolve, i * 6000));
                     ptz.sendMessage(m?.chat, {
                         image: {
                             url: imagesUrls[i]
                         },
                         caption: `Image *(${i + 1}/${totalCount})*\n\nRemaining Credits: ${credits}\nPrompt: ${text}`
                     }, {
                         quoted: fsaluran
                     });
                 } catch (error) {
                     console.error(`Error sending file: ${error.message}`);
                     await reply(`Failed to send image *(${i + 1}/${totalCount})*`);
                 }
             }
         } else {
             await reply('No images found after filtering.');
         }
     } catch (error) {
         await reply('An error occurred while processing the request.');
     }
 };
 break
 //=================================================//
 case "ping":
 case "botstatus":
 case "statusbot": {

     let respon = ` *ᴘ ɪ ɴ ɢ*  
 ${latensi.toFixed(4)} ms 

 *ʀ ᴜ ɴ ᴛ ɪ ᴍ ᴇ*
 ${runtime(process.uptime())} 

 *s ᴇ ʀ ᴠ ᴇ ʀ* 
 *🛑 ʀᴀᴍ:* ${formatSize(ramused)} (${persenramm?.toString().split('.')[0]}%) / ${formatSize(totalram)} 
 *🔵 ғʀᴇᴇRAM:* ${formatSize(sisaram)} 
 *🔴 ᴍᴇᴍᴏʀy:* ${ram}
 *🗂 ᴅɪꜱᴋ:* ${formatSize(diskused)} / ${formatSize(totalspace)}
 *📂 ғʀᴇᴇDISK:* ${formatSize(freespace)}
 *🔭 ᴘʟᴀᴛғᴏʀᴍ:* ${os.platform()}
 *🧿 sᴇʀᴠᴇʀ:* ${os.hostname()}
 *📤 ᴜᴘʟᴏᴀᴅ:* ${upload}
 *📥 ᴅᴏᴡɴʟᴏᴀᴅ:* ${download}
 *⏰ ᴛɪᴍᴇ sᴇʀᴠᴇʀ:* ${jam} : ${menit} : ${detik}
 
 *📮 ɴᴏᴅᴇᴊꜱ ᴠᴇʀꜱɪᴏɴ:* ${process.version}
 *💻 ᴄᴘᴜ ᴍᴏᴅᴇʟ:* ${cpuuuu[0].model}
 *📊 ᴏꜱ ᴠᴇʀꜱɪᴏɴ:* ${os.version()}
 
_NodeJS Memory Usaage_
${Object.keys(used)
.map(
(key, _, arr) =>
`${key.padEnd(Math.max(...arr.map((v) => v.length)), " ")}: ${formatp(
used[key],
)}`,
)
.join("\n")}
${readmore}
${cpus[0]
? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times)
.map(
(type) =>
`- *${(type + "*").padEnd(6)}: ${(
(100 * cpu.times[type]) /
cpu.total
).toFixed(2)}%`,
)
.join("\n")}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus
.map(
(cpu, i) =>
`${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(
cpu.times,
)
.map(
(type) =>
`- *${(type + "*").padEnd(6)}: ${(
(100 * cpu.times[type]) /
cpu.total
).toFixed(2)}%`,
)
.join("\n")}`,
)
.join("\n\n")}`
: ""
}
`.trim();
     ptz.relayMessage(m?.chat, {
         requestPaymentMessage: {
             currencyCodeIso4217: 'USD',
             amount1000: 999999999,
             requestFrom: '0@s.whatsapp.net',
             noteMessage: {
                 extendedTextMessage: {
                     text: respon,
                     contextInfo: {
                         mentionedJid: [m?.sender],
                         externalAdReply: {
                             showAdAttribution: true
                         }
                     }
                 }
             }
         }
     }, {})
 }
 break
 
 case "vps": case "panel": {
    await ptz.sendMessage(m.chat, { react: { text: `🚀`, key: m.key } });

   
    var link = `*\`DIGITAL OCEAN VPS\`*


🗓30 DAY PRICE LIST

☁️2TB - Rs.350.00
☁️3TB - Rs.450.00
☁️4TB - Rs.550.00

🗓 60 DAY PRICE LIST

☁️2TB - Rs.550.00
☁️3TB - Rs.850.00
☁️4TB - Rs.1000.00

Buy: t.me/Danuwazero

*\`PANEL\`*
${readmore}
➪ RESELLER PANEL Rs.1500.00
➪ ADMIN PANEL Rs.1000.00
➪ OWNER PANEL   Rs.2000.00
➪ PT PANEL Rs.3000.00
➪ PANEL 1GB-12GB
➪ PANEL UNLIMITED
➪ (BUY PT PANEL DPT 2 SERVER)

🚀 DIGITAL OCEAN SERVER 🚀

❗ANTI DELAY!! SERVER PRIVATE

❗NONSTOP WORKING

❗HIGH SPEED

Buy: t.me/smartsquardyt
`

    return reply(link)
    }
    break
 
 case "apk": {
    if (!text) return reply("Please provide a search query. Usage: apk<query>");
    
    try {
        // React with a loading emoji
        await ptz.sendMessage(m.chat, { react: { text: '🕖', key: m.key }});
        
        // Fetch data from the API
        const { data } = await axios.get(`https://api.genux.me/api/download/apk?query=${text}&apikey=GENUX-SANDARUX`);
        console.log("API Response:", JSON.stringify(data, null, 2));

        // Use icon instead of thumbnail since that's what the API returns
        await ptz.sendMessage(m.chat, {
          image: { url: data.result.icon }, // Changed from thumbnail to icon
          caption: `💬 *Name*: ${data.result.name}\n\n⬇ *Last update*: ${data.result.lastup}\n\n💱 *Package*: ${data.result.package}\n\n🎀 *Size*: ${data.result.size}`,
          contextInfo: {
            mentionedJid: [
              m.sender,
              "0@s.whatsapp.net",
              owner[0] + "@s.whatsapp.net"
            ],
            forwardingScore: 10,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363364919754231@newsletter",
              serverMessageId: null,
              newsletterName: "Join For More Info"
            }
          },
          quoted: fsaluran 
        });
        
        
      
        await ptz.sendMessage(
          m.chat,
          {
            document: { url: data.result.dllink },
            fileName: `${data.result.name}.apk`,
            mimetype: 'application/vnd.android.package-archive',
            quoted: fsaluran, // Make sure `quoted` is passed correctly
          }
        );
 
        
        // Remove the loading emoji
        await ptz.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
    } catch (error) {
        console.error("Error:", error);
        await ptz.sendMessage(m.chat, { react: { text: '❌', key: m.key }});
        reply(`Error: ${error.message}`);
    }
    break;
}
    
    case "xvdl":
case "xv":
    const xtRegex = /^(https?:\/\/)?(www\.)?xvideos\.com\/video\.[a-zA-Z0-9]+\/.+/;
if (!xtRegex.test(text)) return reply("Please enter a valid XVideos URL. To get Link Type Ex: .xvsearch Indian");

    if (!text) return reply(`❌ Please provide a Link.`);
    if (!m.isGroup) return reply("Group only!");

    try {
        await ptz.sendMessage(m.chat, {
            react: { text: "🎥", key: m.key },
        });
 

        
                
        
                // Fetch the video details from the API
                const {data} = await axios.get(`https://api.giftedtech.web.id/api/download/xvideosdl?apikey=gifted&url=${text}`);
                
        
                const wait = await ptz.sendMessage(
                  m.chat,
                  { text: "Downloading.... " },
                  { quoted: fsaluran }
                );
        
                if (!data || !data.result) {
                  return reply("❌ No results found.");
                }
        
                await ptz.sendMessage(m.chat, {
                  image: { url: data.result.thumbnail },
                  caption: `💬 *Title*: ${data.result.title}\n\n👀 *Views*: ${data.result.views}\n\n👍 *Likes*: ${data.result.likes}\n\n👎 *Dislikes*: ${data.result.dislikes}\n\n🎀 *Size*: ${data.result.size}`,
                  contextInfo: {
                    mentionedJid: [
                      m.sender,
                      "0@s.whatsapp.net",
                      owner[0] + "@s.whatsapp.net",
                    ],
                    forwardingScore: 10,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                      newsletterJid: "120363364919754231@newsletter",
                      serverMessageId: null,
                      newsletterName: "Join For More Info",
                    },
                  },
                });
        
                await ptz.sendMessage(
                  m.chat,
                  {
                    video: { url: data.result.download_url },
                    fileName: data.result.title + ".mp4",
                    mimetype: "video/mp4",
                    caption: "*Done ✅*",
                    contextInfo: {
                      forwardingScore: 10,
                      isForwarded: true,
                    },
                  },
                  { quoted: m }
                );
          
                await ptz.sendMessage(m.chat, {
                  text: `*Uploaded✅*`,
                  edit: wait.key,
                });
        
              } catch (error) {
                console.error(error);
                reply("❌ An error occurred while fetching the video.");
              }
            
            break;
              case 'mediafire': {
    await ptz.sendMessage(m.chat, { react: { text: `🗂`, key: m.key } });
    
    if (!text) return reply(`Example: https://www.mediafire.com/file/xxxxxxxxx/xxxxx.zip/file`);

    try {
        // Fetch data from API
        const {data}= await axios.get(`https://restapi.simplebot.my.id/api/download/mediafire?url=${text}`);
        
console.log (data)
        
        // Check if API response is valid
        if (!data || !data.result || !data.result.link) {
            return m.reply('Invalid response from API. Please check your API key and URL.');
        }

        // Send "Downloading..." message
        const wait = await ptz.sendMessage(m.chat, { text: "Downloading...." }, { quoted: fsaluran });

        // Send the file
        await ptz.sendMessage(m.chat, {
            document: { url: data.result.url },
            mimetype: 'application/zip',
            fileName: `${data.result.filename}.zip`, // Ensures correct file format
            caption: `▢ *NAME* : ${data.result.filename}\n▢ *SIZE* : ${data.result.size}`
        }, { quoted: m });

        // Edit the message to confirm upload
        await ptz.sendMessage(m.chat, { text: `*Uploaded✅*`, edit: wait.key });

    } catch (error) {
        console.error('Error downloading MediaFire file:', error);
        reply('Failed to download the file. Please check the link and try again.');
    }
}
break; 
    
     case 'xvideosearch': 
case 'xvsearch': { 
    await ptz.sendMessage(m.chat, { react: { text: `🔞`, key: m.key } });
    if (!text) return reply("Example: Indian hot girl"); // Check if query is provided
    await ptz.sendMessage(m.chat, { react: { text: `🔍`, key: m.key } });

    const { data } = await axios.get(`https://api.giftedtech.web.id/api/search/xvideossearch?apikey=gifted&query=${text}`);
    
    if (!data.success || !data.results.length) return reply("No results found for: " + text);
    
    let teks = `🔍 XV Search Results for "${text}"\n\n`;
    let no = 1;
    
    // Loop through results and format them
    for (let i of data.results) {
        teks += `${no}. *Title*: ${i.title}\n`;
        teks += `   *Duration*: ${i.duration}\n`;
        teks += `   *URL*: ${i.url}\n\n`;
        no++;
    }
    
    // Send the first thumbnail as an image with the formatted text as caption
    if (typeof m.chat !== 'string') {
        console.error('Invalid chat ID:', m.chat);
        return;
    }
    
    console.log('Sending message to chat:', m.chat);
    console.log('Message content:', { image: { url: data.results[0].thumb }, caption: teks });
    
    ptz.sendMessage(m.chat, { 
        image: { url: data.results[0].thumb }, 
        caption: teks 
    }, { quoted: m });
}
break;
 case 'spotify': case 'spotifysearch': {
        if (!text) return reply(`Example: alan walker alone`);
        try {
            const { data } = await axios.get(`https://api.giftedtech.web.id/api/search/spotifysearch?apikey=gifted&query=${text}`);
          
    
            let txt = data.results.map(a => {
                return `Spotify Search\n\n*Name:* ${a.title}\n- Artist: ${a.artist}\n- Duration: ${a.duration}\n- Url: ${a.url}`;
            }).join('\n\n');
    
            reply(txt);
        } catch (e) {
            reply('Server Search Offline!');
        }
    }
    break;
 
case "alive": {
                await ptz.sendMessage(m.chat, { react: { text: `💖`, key: m.key } });

                const caption = `Hello @${m?.sender.split('@')[0]} I am Alive now!\n\n• Type "menu" for more information ℹ️`;

                await ptz.sendMessage(
                    m.chat,
                    {
                        document: fs.readFileSync("./package.json"),
                        fileName: `Wa-bot`,
                        mimetype: `application/pdf`,
                        fileLength: "100000000000000",
                        pageCount: "99",
                        caption: caption,
                        contextInfo: {
                            mentionedJid: [
                                m.sender,
                                "0@s.whatsapp.net",
                                owner[0] + "@s.whatsapp.net",
                            ],
                            forwardingScore: 10,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: `120363364919754231@newsletter`,
                                serverMessageId: null,
                                newsletterName: "Join For More Info",
                            },
                            externalAdReply: {
                                title: `Simple Wa-bot`,
                                body: `Click here`,
                                showAdAttribution: true,
                                thumbnailUrl: `https://files.catbox.moe/bdbhse.jfif`,
                                mediaType: 1,
                                previewType: 0,
                                renderLargerThumbnail: true,
                                mediaUrl: `https://files.catbox.moe/bkf68z.png`,
                                sourceUrl: `https://wa.me/94764497078`,
                            },
                        },
                    },
                    { quoted: fsaluran }
                );
                break;
            }
            // ... other cases ...
        } // Closes switch(command)

    } catch (err) {
        console.log(util.format(err))
    }

    // File watcher
    let file = require.resolve(__filename)
    fs.watchFile(file, () => {
        fs.unwatchFile(file)
        console.log(color(`Update ${__filename}`))
        delete require.cache[file]
        require(file)
    })
}